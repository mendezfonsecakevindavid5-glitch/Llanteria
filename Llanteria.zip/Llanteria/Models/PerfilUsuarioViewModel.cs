using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Llanteria.Models
{
    public class PerfilUsuarioViewModel
    {
        public int Id { get; set; }

        public string? Bio { get; set; }

        public string? TemaPreferencia { get; set; }

        public bool NotificacionesActivas { get; set; }

        /// <summary>Foto nueva ya recortada en el navegador (JPEG de 200x200 como data URL). Vacía si no se cambió.</summary>
        public string? FotoRecortada { get; set; }

        public string? FotoBase64 { get; set; }

        [Required(ErrorMessage = "Los nombres son obligatorios")]
        [StringLength(100)]
        public string Nombres { get; set; } = null!;

        [Required(ErrorMessage = "Los apellidos son obligatorios")]
        [StringLength(100)]
        public string Apellidos { get; set; } = null!;

        public string NombreCompleto => $"{Nombres} {Apellidos}".Trim();

        /// <summary>Rol con el que se muestra el perfil (solo lectura).</summary>
        public string? Rol { get; set; }

        public string Correo { get; set; } = null!;

        [Required(ErrorMessage = "El teléfono es obligatorio")]
        public string Telefono { get; set; } = null!;

        public string? Direccion { get; set; }

        public int Puntos { get; set; }

        /// <summary>Vehículos del cliente con su historial (vacío si la cuenta no es de un cliente).</summary>
        public List<VehiculoHistorial> Vehiculos { get; set; } = new List<VehiculoHistorial>();

        // Ahora apunta a modelos de datos reales
        public List<FacturaViewModel> FacturasRecientes { get; set; } = new List<FacturaViewModel>();
    }

    public class FacturaViewModel
    {
        public int Id { get; set; }
        public string NumeroFactura { get; set; } = null!;
        public DateTime Fecha { get; set; }
        public decimal TotalPagar { get; set; }
        public string ServicioPrincipal { get; set; } = "N/A";
        public string DetalleItems { get; set; } = "N/A";
        public string EstadoPago { get; set; } = "Pendiente";
    }
}